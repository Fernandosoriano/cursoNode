import cursos from './courses.json';
import estudiantes from './students.json';

export const database = {
    cursos,
    estudiantes
}